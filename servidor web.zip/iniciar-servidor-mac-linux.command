#!/bin/bash
cd "$(dirname "$0")"
echo "Iniciando servidor local para la web de Cauce..."
( sleep 1 && (open http://localhost:8000/cauce-landing.html 2>/dev/null || xdg-open http://localhost:8000/cauce-landing.html 2>/dev/null) ) &
python3 -m http.server 8000
