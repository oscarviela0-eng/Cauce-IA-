@echo off
cd /d "%~dp0"
echo Iniciando servidor local para la web de Cauce...
start http://localhost:8000/cauce-landing.html
python -m http.server 8000
